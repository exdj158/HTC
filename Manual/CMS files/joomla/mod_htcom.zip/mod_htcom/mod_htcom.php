<?php
//don't allow other scripts to grab and execute our file
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
$url = 'http://localhost/HttpCommander/Default.aspx';
$link_text = "Http commander";
$user =& JFactory::getUser();
if (!$user->guest) {
	$url .= "?username=" . urlencode($user->username);
	$url .= "&passwordhash=" . urlencode($user->password);
}
echo "<p><a href=\"{$url}\">{$link_text}</a></p>";
?>
