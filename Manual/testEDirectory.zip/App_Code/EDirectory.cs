﻿using System.IO;
using System.Net;
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Collections.Generic;
using System.DirectoryServices;

public static class EDirectory
{
    public static List<string> Main()
    {
        string LDAPContainer = "LDAP://kub-win2003ent";
        string EDirectoryBindUserDN = "cn=user1,O=ELEMIT";
        string EDirectoryBindUserPassword = "";
        List<string> paths = new List<string>();

        using (DirectoryEntry deRoot = new DirectoryEntry(LDAPContainer, EDirectoryBindUserDN, EDirectoryBindUserPassword, AuthenticationTypes.SecureSocketsLayer))
        {
            using (DirectorySearcher searcher = new DirectorySearcher(deRoot))
            {
                searcher.Filter = "(objectClass=Person)";
                SearchResultCollection results = searcher.FindAll();

                foreach (SearchResult result in results)
                {
                    paths.Add(result.Path);
                    //Response.Write(HttpUtility.HtmlEncode(result.Path) + "<br/>");
                    //string uid = (string)result.Properties["uid"][0];
                    //Response.Write(HttpUtility.HtmlEncode(uid) + "<br/>");
                }
            }
        }
        return paths;
    }
}
